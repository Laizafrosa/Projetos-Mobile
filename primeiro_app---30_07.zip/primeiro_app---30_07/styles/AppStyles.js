import{SafeAreaView} from 'react-native';

const AppStyles = StyleSheet.create({

});

export default AppStyles;

