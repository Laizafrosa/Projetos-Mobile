import {SafeAreaView} from 'react-native';
import AppStyles from './styles/AppStyles';

const App =() => {
  return (
    <SafeAreaView style={styles.container}>
    <view style ={ AppStyles.header}>
    <text>
    My First Header
    </text>
    </view>
    <view style={AppStyles.body}>
    <text>
    My app body
    </text>
    </view>
    <view style={AppStyles.footer}>
    <text>
    My app footer
    </text>
    </vi
      
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({

});
