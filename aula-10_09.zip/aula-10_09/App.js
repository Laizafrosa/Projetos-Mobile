import {useState} from 'react';
import { Text, SafeAreaView, StyleSheet, Button } from 'react-native';

export default function App() {
  const [message, setMessage] = useState('Clique no botão.');
  return (
    <SafeAreaView style={styles.container}>
      <Button title="Autenticar" onPress={() => {
        fetch("https://b7e8465c-4c94-4184-b09a-6f80212780a6.mock.pstmn.io/auth_fail")
          .then(response => response.json())
          .then(data => {
            if(data.result == 'success'){
              setMessage('Autenticação ok! Você será redirecionado...');
            }else{
              setMessage('Sua autenticação falhou! Tente novamente!');
            }
          })
          .catch(error => {
            setMessage('Aconteceu um erro: ' + error);
          });
      }} />
      <Text style={styles.paragraph}>
        {message}
      </Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
