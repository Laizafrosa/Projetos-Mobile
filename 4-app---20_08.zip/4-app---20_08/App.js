import React from 'react';

import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Text,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const App = () => {
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [errorMessage, setErrorMessage] = React.useState('');
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);

  React.useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    try{
      const savedUsername = await AsyncStorage.getItem('username');
      if(savedUsername){
        setUsername(savedUsername);
        setIsLoggedIn(true);
      }
    }catch(error){
      setErrorMessage('Error: ' + error);
    }
  };

  const handleLogin = async () => {
    if (username === 'admin' && password === 'admin') {
      try{
        await AsyncStorage.setItem('username', username);
        setIsLoggedIn(true);
      }catch(error){
        setErrorMessage('Error: ' + error);
      }
    } else {
      setErrorMessage('Try again...');
    }
  };

  const handleLogout = async () => {
    try{
        await AsyncStorage.removeItem('username');
        setIsLoggedIn(false);
      }catch(error){
        setErrorMessage('Error: ' + error);
      }
  }

  return (
    <View style={styles.external}>
      { isLoggedIn ? (<View style={styles.container}>
        <Text> Hello, {username}! </Text>
        <TouchableOpacity style={styles.button} onPress={handleLogout}>
            <Text style={styles.button_text}>Logout</Text>
          </TouchableOpacity>
      </View>):
      (<View style={styles.container}>
          <TextInput
            style={styles.input}
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            secureTextEntry
            onChangeText={setPassword}
          />
          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.button_text}>Login</Text>
          </TouchableOpacity>
          <Text> {errorMessage} </Text>
      </View>)}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#DDD',
    alignItems: 'center',
    justifyContent: 'center'
  },
  external: {
    flex: 1
  },
  input: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
    width: '80%',
  },
  button: {
    width: '70%',
    paddingVertical: 10,
    backgroundColor: 'blue',
    alignItems: 'center',
    borderRadius: 10,
  },
  button_text: {
    color: 'white',
  },
});

export default App;
