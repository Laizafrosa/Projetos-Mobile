import { SafeAreaView, StyleSheet, ScrollView } from 'react-native';

import Product from './components/Product';

export default function App() {
  const products = [
    {
      image:
        'https://img.irroba.com.br/filters:fill(fff):quality(90)/dhaffyco/catalog/lorena-marrom-frente.jpg',
      name: 'bolsa',
      price: 79.99,
    },
    {
      image:
        'https://img.irroba.com.br/filters:fill(fff):quality(90)/dhaffyco/catalog/lorena-marrom-frente.jpg',
      
      price: 69.99,
    },
    {
      image:
        'https://img.irroba.com.br/filters:fill(fff):quality(90)/dhaffyco/catalog/lorena-marrom-frente.jpg',
      price: 89.99,
    },
    {
      image:
        'https://img.irroba.com.br/filters:fill(fff):quality(90)/dhaffyco/catalog/lorena-marrom-frente.jpg',
      price: 59.99,
    },
  ];
  return (
    <ScrollView>
      <SafeAreaView style={styles.container}>
        {products.map((product, index) => (
          <Product
            key={index}
            image={product.image}
            name={product.name}
            price={product.price}
          />
        ))}
      </SafeAreaView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
});
